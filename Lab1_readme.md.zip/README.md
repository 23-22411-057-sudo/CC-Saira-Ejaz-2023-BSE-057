# 🧪 Cloud Computing Lab 1

**Student:** Saira Ejaz  
**Roll No:** 2023-BSE-057  
**Section:** 5-B

## 📌 Lab Task
### Installation of Ubuntu in VMware Workstation
## Step 1: VMware Installation

![Step 1](images/step1.png)

## Step 2: Download Ubuntu server ISO

![Step 2](images/step2.png)

## Step 3: Create a new virtual machine in VMware

![Step 3](images/step3.png)

## Step 4: Start the virtual machine

![Step 4](images/step4.png)

## Step 5: Accessing Ubuntu Server from Windows

![Step 5](images/step5.png)

## Step 6: Connect via SSH from Windows

![Step 6](images/step6.png)

## Step 7: Accept the fingerprint

![Step 7](images/step7.png)

## Step 8: Enter your password

![Step 8](images/step8.png)
